//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var s:Int

s = 100
var a,b,c : Int
a=1000
b=100
c=3
let x = 6000
let y:Int
y = 6000
var z = y
z = 10
print(str)
print (str)
print(s)
print(x,y)
c = a + b
print(c)
print()
print(a,"+",b,"=",c,separator:",",terminator:" ")
print("\(a) + \(b)=\(c)")
if a > b
{
    if a > c
    {
        print(" a is max")
    }
    else{
        print("c is max")
        
    }
}
else{
    if b > c{print("b is max")}

else
{
    print("c is max")
    
}
}
if ((a<b) && (a<c))
{
    print("a is min")
}
else if((b<a) && (b<c))
{
    print("b is min")
}
else
{
    print("c is min")
}
for i in 1...10
{
    print(i)
}
  for i in 1..<10
  {
    print(i)
}
for j in stride(from:0,to:50,by: 5)
   {
    print(j)
}
while(i<=10)
{
    print(i)
    i=i+1
}
var t=(10,20)
print(t,0)
print(t,1)
    
    
    
    
    
    
    
    
    

